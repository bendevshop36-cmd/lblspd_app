# lspd_app

Application **LSPD** pour **LB Phone** et **LB Tablet** (ESX). Gratuite, par BENDEV SHOP.

- Support : https://discord.gg/V62mDxfCmr

Script gratuit, tu peux le modifier et le partager. Merci de garder le nom de l'auteur. Revente interdite.

## Ce que fait l'app

- **Annonces** du département (catégories, image, publication/dépublication, notification aux joueurs)
- **Niveau d'alerte DEFCON** à 5 niveaux, avec nom, couleur et message modifiables en jeu
- **Recrutement** : ouverture/fermeture, conditions, formulaire de candidature, suivi et réponse aux candidats
- **Informations** : présentation, missions, organisation, unités, grades, services, adresse, horaires, contacts, FAQ, règlement
- **Historique** des actions de gestion
- Gestion des droits par **job et grade ESX**, toujours revérifiée côté serveur
- Fonctionne sur **LB Phone** et **LB Tablet**, au choix ou les deux
- Rafraîchissement en direct et notifications via LB Phone / LB Tablet
- Tables SQL créées automatiquement au démarrage

## Dépendances

- es_extended
- oxmysql
- lb-phone et/ou lb-tablet

## Installation

1. Mets le dossier `lspd_app` dans ton dossier `resources`.
2. Ajoute `ensure lspd_app` dans ton `server.cfg`, **après** `es_extended`, `oxmysql`, `lb-phone` et `lb-tablet`.
3. Redémarre le serveur. Les tables `lspd_settings`, `lspd_announcements`, `lspd_applications` et `lspd_logs` se créent toutes seules (`sql/install.sql`).
4. Les joueurs téléchargent l'app depuis l'App Store du téléphone ou de la tablette (voir `Config.DefaultApp` pour l'installer d'office).

## Configuration (`config.lua`)

| Option | Rôle |
|---|---|
| `Config.Phone` / `Config.Tablet` | Active ou désactive un support |
| `Config.DefaultApp` | `true` = installée d'office chez tout le monde |
| `Config.AppIdentifier`, `AppName`, `AppDescription` | Identité de l'app |
| `Config.IconFile` | Icône de l'app dans `html/` |
| `Config.PoliceJobs` | Jobs ESX autorisés dans l'administration (`police`, `lspd` par défaut) |
| `Config.BossGradeNames` | Noms de grade considérés comme patron (toutes les permissions) |
| `Config.MinGrade` | Grade minimum par permission |
| `Config.AdminGroups` | Groupes ESX ayant toutes les permissions |
| `Config.Defcon`, `DefconInverted` | Niveaux d'alerte, sens de l'échelle |
| `Config.Categories` | Catégories d'annonces |
| `Config.ApplyCooldown`, `RateLimitMs`, `MaxText` | Anti-spam et limites |

Grades minimum par défaut : annonces 3, recrutement 4, informations 5, DEFCON 6, historique 6.

Si ton job police ne s'appelle ni `police` ni `lspd`, ajoute-le dans `Config.PoliceJobs`.

## Problèmes courants

- **Page blanche sur la LB Tablet** : mets `Config.TabletUiWithResourceName = true`, puis redémarre la ressource.
- **L'app n'apparaît pas** : vérifie que `lspd_app` est lancé après `lb-phone` / `lb-tablet`, et que `Config.DefaultApp = false` demande bien de l'installer depuis l'App Store.
- **« Initialisation en cours »** : oxmysql n'est pas démarré ou la base est inaccessible, regarde la console.
- **Je ne vois pas l'onglet de gestion** : ton job ou ton grade ne passe pas `Config.PoliceJobs` / `Config.MinGrade`.
- **Changer le nom du dossier** : possible, aucune autre modification n'est nécessaire.

## Remarques

- L'interface est en français.
- Les images d'annonces doivent être des liens `http(s)`.
