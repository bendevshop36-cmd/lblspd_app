local RESOURCE = GetCurrentResourceName()

-- ───────────── Définition de l'app ─────────────
local function appDefinition(system)
    -- LB Phone : chemin complet « ressource/dossier/fichier.html »
    -- LB Tablet : chemin relatif à la ressource qui enregistre l'app
    local ui = RESOURCE .. '/html/index.html'
    if system == 'lb-tablet' and not Config.TabletUiWithResourceName then
        ui = 'html/index.html'
    end
    return {
        identifier  = Config.AppIdentifier,
        name        = Config.AppName,
        description = Config.AppDescription,
        developer   = 'LSPD',
        defaultApp  = Config.DefaultApp,
        size        = 6500,
        ui          = ui,
        icon        = ('https://cfx-nui-%s/html/%s'):format(RESOURCE, Config.IconFile or 'logo.png'),
        fixBlur     = true
    }
end

local function register(system)
    local ok, success, reason = pcall(function()
        return exports[system]:AddCustomApp(appDefinition(system))
    end)
    if not ok then
        print(('^1[lspd_app] impossible d\'enregistrer l\'app dans %s : %s^7'):format(system, tostring(success)))
    elseif success == false then
        print(('^3[lspd_app] %s a refusé l\'app : %s^7'):format(system, tostring(reason)))
    end
end

local function registerAll()
    if Config.Phone  and GetResourceState('lb-phone')  == 'started' then register('lb-phone')  end
    if Config.Tablet and GetResourceState('lb-tablet') == 'started' then register('lb-tablet') end
end

-- ───────────── Pont interface <-> serveur ─────────────
-- Droits toujours revérifiés côté serveur.
local ESX = exports['es_extended']:getSharedObject()

RegisterNUICallback('api_lspd_app', function(data, cb)
    if type(data) ~= 'table' or type(data.action) ~= 'string' then
        return cb({ ok = false, error = 'Requête invalide.' })
    end
    ESX.TriggerServerCallback('lp:api', function(result)
        cb(result or { ok = false, error = 'Pas de réponse du serveur.' })
    end, data.action, data.payload or {})
end)

-- ───────────── Enregistrement (attend LB Phone / LB Tablet) ─────────────
CreateThread(function()
    local waited = 0
    while waited < 60000 do
        if (not Config.Phone  or GetResourceState('lb-phone')  == 'started')
        and (not Config.Tablet or GetResourceState('lb-tablet') == 'started') then
            break
        end
        Wait(500)
        waited = waited + 500
    end
    registerAll()
end)

AddEventHandler('onResourceStart', function(name)
    if name == 'lb-phone' or name == 'lb-tablet' then
        Wait(500)
        registerAll()
    end
end)

-- ───────────── Rafraîchissement temps réel (envoyé par le serveur) ─────────────
RegisterNetEvent('lspd_app:client:refresh', function()
    local evt = Config.RefreshEvent or 'refresh'
    if Config.Phone and GetResourceState('lb-phone') == 'started' then
        pcall(function() exports['lb-phone']:SendCustomAppMessage(Config.AppIdentifier, { event = evt }) end)
    end
    if Config.Tablet and GetResourceState('lb-tablet') == 'started' then
        pcall(function() exports['lb-tablet']:SendCustomAppMessage(Config.AppIdentifier, evt, {}) end)
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= RESOURCE then return end
    if GetResourceState('lb-phone') == 'started' then
        pcall(function() exports['lb-phone']:RemoveCustomApp(Config.AppIdentifier) end)
    end
    if GetResourceState('lb-tablet') == 'started' then
        pcall(function() exports['lb-tablet']:RemoveCustomApp(Config.AppIdentifier) end)
    end
end)
