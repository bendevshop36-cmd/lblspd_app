--[[
    lspd_app : application LSPD pour LB Phone / LB Tablet (ESX)
    Gratuit, par BENDEV SHOP. Modifiable et partageable, merci de garder le nom de l'auteur.
    Support : https://discord.gg/V62mDxfCmr
]]

Config = {}

Config.AppIdentifier = 'lspd-app'          -- identifiant unique de l'app (phone + tablet)
Config.AppName       = 'LSPD'
Config.AppDescription = 'Application officielle du Los Santos Police Department'

-- Compatibilité : mettre false pour désactiver un des deux supports
Config.Phone  = true   -- LB Phone
Config.Tablet = true   -- LB Tablet

-- LB Tablet : false = chemin « html/index.html » (recommandé par la doc LB Tablet).
-- Si l'app reste blanche sur la tablette, essayer true.
Config.TabletUiWithResourceName = false

-- Icône de l'app (dans html/). Le logo de l'interface reste html/logo.png
Config.IconFile = 'icon.png'

-- Nom de l'évènement envoyé à l'interface pour la rafraîchir en temps réel
Config.RefreshEvent = 'lspd:refresh'

-- false = l'app n'est PAS installée d'office : les joueurs la téléchargent depuis l'App Store du téléphone/tablette.
-- true  = installée directement chez tout le monde.
Config.DefaultApp    = false


-- Jobs ESX autorisés dans l'administration
Config.PoliceJobs = { police = true, lspd = true }
-- Noms de grade (job_grades.name) considérés comme "patron" : toutes les permissions
Config.BossGradeNames = { boss = true }
-- Grade ESX minimum (job_grades.grade) par permission
Config.MinGrade = { announcements = 3, recruitment = 4, info = 5, defcon = 6, history = 6 }
-- Groupes ESX ayant toutes les permissions
Config.AdminGroups = { superadmin = true, admin = true }

Config.RateLimitMs      = 300    -- délai min entre deux requêtes d'un joueur
Config.ApplyCooldown    = 600    -- secondes entre deux candidatures d'un même joueur
Config.MaxText          = 2000
Config.RequestTimeout   = 8000   -- ms (côté client)
Config.MaxAnnouncements = 50

Config.Categories = { 'Informations générales', 'Prévention', 'Sécurité publique', 'Recrutement', 'Alertes', 'Événements' }

-- Chaque niveau a un nom, une couleur et un MESSAGE (envoyé aux citoyens quand vous choisissez ce niveau).
-- Tout est modifiable en jeu : Gestion > Alerte > "Personnaliser les 5 niveaux".
Config.DefconInverted = false   -- false : 5 = calme, 1 = critique. true : 1 = calme, 5 = le plus grave.
Config.Defcon = {
  [5] = { title = 'Situation normale',   color = '#2ecc71', message = 'Aucune menace particulière. Les services fonctionnent normalement.' },
  [4] = { title = 'Vigilance renforcée', color = '#f1c40f', message = 'Activité suspecte signalée en ville. Les patrouilles sont renforcées, restez attentifs.' },
  [3] = { title = 'Menace sérieuse',     color = '#e67e22', message = 'Des groupes criminels sont actifs. Évitez les zones concernées et signalez toute activité suspecte.' },
  [2] = { title = 'Alerte élevée',       color = '#e74c3c', message = 'Menace importante : affrontements armés possibles. Restez chez vous si possible et suivez les consignes du LSPD.' },
  [1] = { title = 'Situation critique',  color = '#b00020', message = 'Urgence maximale. Zones bouclées, couvre-feu possible. Obéissez aux consignes des forces de l\'ordre.' },
}

-- Clés d'information modifiables ('text' ou 'list' = tableau de {t,d})
Config.InfoKeys = {
  about = 'text', missions = 'text', organisation = 'text', units = 'list', ranks = 'list', services = 'text',
  address = 'text', hours = 'text', useful = 'text', contacts = 'text', faq = 'list', rules = 'text',
}

-- Valeurs initiales (insérées uniquement si absentes)
Config.Defaults = {
  defcon  = { level = 5, description = Config.Defcon[5].message },
  recruit = { open = false, conditions = 'Casier vierge, sérieux et respect du règlement.', minAge = 21,
              availability = 'Plusieurs soirées par semaine.', training = 'Formation à l\'académie de police.',
              presentation = 'Servir et protéger les habitants de Los Santos.' },
  ['info:about']   = 'Le Los Santos Police Department protège les habitants de Los Santos.',
  ['info:address'] = 'Mission Row Police Station, Los Santos',
}
