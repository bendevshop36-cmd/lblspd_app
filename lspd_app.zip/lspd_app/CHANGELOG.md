# Changelog

## 1.1.0
- Correction du bug de page blanche à l'ouverture de l'app sur la LB Tablet
- Optimisation globale (performances, stabilité)
- Dossier réorganisé (client / server / html / sql), README et configuration documentés
- Le nom de la ressource n'est plus écrit en dur dans l'interface

## 1.0.0
- Première version
