fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'lspd_app'
author 'Bendev (BENDEV SHOP)'
description 'Application LSPD pour LB Phone et LB Tablet (ESX) : annonces, DEFCON, recrutement, infos'
version '1.1.0'

dependencies {
    'es_extended',
    'oxmysql'
}

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/sql.lua',
    'server/main.lua'
}

files {
    'html/index.html',
    'html/icon.png',
    'html/logo.png'
}
